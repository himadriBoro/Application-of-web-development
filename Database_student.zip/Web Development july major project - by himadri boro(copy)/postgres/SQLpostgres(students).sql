select *from students
CREATE TABLE students( sno int, name varchar(300) ,phone int, email varchar(300),course varchar(300));


INSERT INTO students VALUES(1,'himadri',1234544678,'xyz@gamil.com','webdevelopment'),(2,'kajal',1234567891,'xxx@gamil.com','webdevelopment');
INSERT INTO students VALUES(3,'namrita',1234567893,'yyy@gmail.com','webdevelopment'),(4,'bhanita',1234567895,'zzz@gmail.com','webdevelopment');
INSERT INTO students VALUES(5,'amrita',1234598763,'abc@gmail.com','webdevelopment'),(6,'narayan',1267354691,'ABC@gmail.com','webdevelopment');
INSERT INTO students VALUES(7,'minaksi',1234567843,'aaa@gmail.com','webdevelopment'),(8,'amitabh',1234567888,'pqr@gmail.com','webdevelopment');

SELECT *FROM students
WHERE name='amrita';

SELECT *FROM students
WHERE name='kajal';

SELECT *FROM students
WHERE sno=4;





