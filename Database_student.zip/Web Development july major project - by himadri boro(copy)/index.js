const express =require("express");
const studentRoutes=require('./src/student/routes');
const app = express();
app.use(express.json());
app.get("/",(req,res)=>{
    res.send("hello");
});
app.use('/students', studentRoutes);
app.listen(3000,()=>console.log("surver running "));