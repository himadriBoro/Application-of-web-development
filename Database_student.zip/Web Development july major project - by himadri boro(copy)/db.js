const   Pool = require('pg').Pool;
const  pool= new Pool({
    host:'localhost',
    port:2805,
    user:'postgres',
    password:'Helaxy.22',
    database:'students'
});

module.exports=pool;