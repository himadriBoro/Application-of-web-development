const {Router} =require("express");
const controller=require("./controller");
const router=Router();

router.get("/",controller.getStudents);
router.get("/:sno", controller.getStudentsBySno);
router.post("/", controller.addStudent);
router.delete("/:sno", controller.removeStudent);




module.exports=router;
