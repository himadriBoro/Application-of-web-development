const { updateStudent } = require("./controller");

const getStudents= "SELECT * FROM students";
const getStudentsBySno = "SELECT * FROM students WHERE sno=$1";
const cheakEmailsExists=" SELECT s FROM students s WHERE s.email =&1";
const addStudent="INSERT INTO students (sno,name,phone, email,course) VALUES($1 ,$2, $3, $4, $5)";
const removeStudent="DELETE FROM students WHERE sno= $1";

module.exports={
    getStudents,
    getStudentsBySno,
    cheakEmailsExists,
    addStudent,
    removeStudent,
    


};