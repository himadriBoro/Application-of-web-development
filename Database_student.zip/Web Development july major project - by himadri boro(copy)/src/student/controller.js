const pool=require('../../db');
const queries =require("./queries");
const getStudents=(req,res)=>{
    pool.query(queries.getStudents, (error,results)=>{
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};


const getStudentsBySno=(req,res)=>{
    const sno=parseInt(req.params.sno);
   pool.query(queries.getStudentsBySno,[sno],(error,results)=>{
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
const addStudent=(req,res)=>{
    const{sno,name,phone,email,course}=req.body;

    //cheak if email is already exists
   pool.query(queries.cheakEmailsExists,[email],(error,results)=>{
        if(results.rows.lenght) {
            res.send("Emai already exists.please cheak again");
        }
        //add students to db
        pool.query(queries.addStudent,[sno,name, phone,email,course],(error,results)=>{
            if(error) throw error;
            res.status(200).send("students created successfully");
        });
    });
};




const removeStudent=(req,res)=>{
    const sno=parseInt(req.params.sno);
    pool.query(queries.removeStudent,[sno],(error,result)=>{
        const noStudentFound=!results.rows.lenght;
        if(noStudentFound){
        res.send("student doesn't exist .please cheak the spelling again");
    }
   pool.query(queries.removeStudent, [sno],(error,results)=>{
        if(error) throw error;
        res.status(200).send("students has been removed.");
    });

    });

};


module.exports={
    getStudents,
    getStudentsBySno,
    addStudent,
    removeStudent,
    

};